const e=`# Terms of Service for personaxi

**Effective Date:** February 3, 2026  
**Operator:** PersonaXI (Sole Proprietorship, Republic of Korea)  
**Address:** 충청남도 천안시 서북구 번영로 306-15, 104-101, Republic of Korea  
**Support:** support@personaxi.com

---

## Chapter 1: General Provisions

### Article 1: Acceptance of Terms
By accessing or using personaxi ("Service"), operated by PersonaXI ("Company"), you agree to be bound by these Terms of Service. If you do not agree to these terms, you may not access the Service.

### Article 2: Definitions
1. **Member:** A person who has entered into a service agreement under these Terms and uses the Service.
2. **Neuron:** Virtual credits purchased by Members to access paid features within the Service.
3. **Persona:** The collection of AI character settings and assets created by a Member.
4. **User-Generated Content ("UGC"):** All Personas, chat records, and other content created by a Member through the Service.

### Article 3: Modification of Terms
1. The Company shall post these Terms on the Service so that Members can easily access them.
2. If the Company amends these Terms, it shall provide notice at least **7 days** prior to the effective date of the amendment (or **30 days** in the case of amendments unfavorable to Members). If a Member continues to use the Service after the amended Terms take effect, the Member is deemed to have agreed to the amended Terms.

---

## Chapter 2: Account Management

### Article 4: Account Registration
1. Members may register for an account via social login using Google or Kakao.
2. The Company may reject an account registration application in any of the following cases:
   - The applicant uses another person's information.
   - Inaccurate or incomplete information is provided.
   - The application is from a country where the Service is not currently available.
   - The applicant is under the age of **14** and has not obtained parental or guardian consent (in accordance with COPPA and global standards).
3. Account registration is deemed complete when the Company approves the application and the Service is launched on the Member's device.

### Article 5: Account Termination (Withdrawal)
1. A Member may request account termination at any time through the account settings within the Service or by contacting support@personaxi.com.
2. The Company shall process the termination request within **5 business days** and notify the Member upon completion.
3. Upon termination, the Member's personal data and service usage data shall be handled in accordance with the Privacy Policy. Data required to be retained under applicable laws shall be kept for the relevant statutory period.
4. Once an account is terminated, the Member will no longer be able to log in with that account. All Neurons and Creator Contribution held shall be forfeited immediately.

---

## Chapter 3: Service Usage and Obligations

### Article 6: Member Obligations and Prohibited Conduct
1. Members shall not engage in any of the following activities:
   - Creating Personas by impersonating or defaming real individuals.
   - Generating or distributing illegal content, including sexually explicit material involving minors.
   - Using automated tools (bots) to make unauthorized API calls or cause excessive load on the Service's servers.
   - Collecting, storing, or exploiting another person's personal information without authorization.
   - Infringing on the intellectual property rights of the Company or third parties.
   - Engaging in any activity that interferes with the stable operation of the Service.
2. Members shall comply with all applicable laws and these Terms when using the Service.

### Article 7: Fair Use Policy and Account Restrictions
1. **Fair Use Policy ("FUP"):** To ensure stable operation, the Company may temporarily or permanently restrict access to a Member's account if usage significantly exceeds the system average or if abnormal usage patterns are detected.
2. **Notification:** When the Company restricts a Member's account, it shall notify the Member of the reason for the restriction via email (support@personaxi.com). In cases of immediate security risks, the Company may restrict the account first and notify afterward.
3. **Right to Appeal:** A Member may submit an appeal within **14 days** of receiving the restriction notification by contacting support@personaxi.com. The Company shall review the appeal and communicate the result within **10 business days**.
4. If no appeal is filed within the specified period, the restriction shall be considered final.

### Article 8: Intellectual Property and UGC Licensing
1. **Ownership:** All intellectual property rights in UGC created by a Member belong to that Member.
2. **License Grant:** The Member grants the Company a worldwide, royalty-free, non-exclusive license to host, store, reproduce, display, and distribute the UGC **strictly for the purposes of operating, promoting, and improving the Service**. This license remains valid after the Member's account termination, within the scope of the stated purposes. Content that has been specifically deleted by the Member is excluded from this license.
3. The Company shall not use UGC for purposes other than those stated in paragraph 1 without obtaining separate consent from the Member.
4. **GDPR Exception:** If a data subject within the EU requests deletion of their content under Article 17 of the GDPR, the Company shall delete the relevant content in accordance with its legal obligations, and the license granted under paragraph 2 shall be terminated for that content. Content that is required to be retained under applicable legal obligations shall be maintained for the relevant retention period.

---

## Chapter 4: Minor Protection Policy

### Article 9: Protection of Minors
1. The Company implements measures to block and manage harmful information to ensure that minors can develop into healthy individuals.
2. In accordance with global standards (including COPPA), the Company verifies the consent of a parent or legal guardian when a user under the age of **14** attempts to register. Registration shall be denied if such consent is not obtained.
3. The Company operates technical filtering systems to ensure that AI-generated responses do not contain content harmful to minors. Any harmful content discovered shall be deleted immediately.

### Article 10: Minor Protection Officer
- **Name:** An Yu-chan (Representative)
- **Contact:** support@personaxi.com

---

## Chapter 5: Paid Services and Refunds

### Article 11: Purchase of Neurons
1. Members may purchase Neurons through the designated payment processor.
2. **Delivery:** Neurons are credited to the Member's account immediately upon successful payment and are available for use right away.
3. **Refund Policy:**
   - Refunds are available within **7 days** of purchase, provided that **zero (0) Neurons** have been used.
   - Partial refunds are not available due to the nature of digital content.
   - Refund requests shall be submitted to support@personaxi.com. The Company shall process the refund within **5–10 business days** of receipt.
4. **Expiration:**
   - Paid Neurons expire **1 year** from the date of purchase in accordance with applicable commercial laws.
   - Free Neurons (Creator Contribution and promotional credits) expire in accordance with the notice period set by the Company (a minimum of **30 days** advance notice).

### Article 12: Right of Withdrawal
1. In accordance with applicable consumer protection laws, Members may withdraw from a transaction within **7 days** from the date of service delivery.
2. However, due to the nature of digital content, withdrawal may be restricted for content that has already been used after delivery.

### Article 13: Payment and Taxes
1. For international payments, the final amount may vary depending on the applicable tax rate (e.g., VAT) and exchange rates of the relevant country.
2. The payment processor is responsible for the collection and remittance of applicable taxes. Detailed tax information is displayed on the payment page and in the receipt.

### Article 14: Service Suspension or Closure — Refund of Paid Credits
1. If the Company discontinues or suspends the Service for an extended period due to business reasons, it shall provide notice to Members at least **30 days** prior to the suspension date.
2. Within the notice period, the remaining balance of **paid Neurons** held by each Member shall be refunded based on the original payment amount.
3. Creator Contribution and promotional credits received free of charge are not subject to refund.

---

## Chapter 6: Creator Contribution

### Article 15: Earning and Using Creator Contribution
1. Members may earn Creator Contribution as rewards when other Members use their created Personas or through other activities within the Service.
2. Earned Creator Contribution is managed as an internal creator-impact metric, and conversion into Neurons is currently not supported.
3. The earning method and conditions of use for Creator Contribution may be changed in accordance with the Company's operational policies. The Company shall provide advance notice of such changes within the Service.

### Article 16: Nature of Creator Contribution and Prohibition of Cashout
1. Creator Contribution are free credits issued to encourage participation in the Service. Under no circumstances may they be cashed out or sold or transferred to a third party for value.
2. The Company does not guarantee any cash value for Creator Contribution. If a Member is found to have attempted to cash out or trade Creator Contribution, the relevant points may be forfeited and the Member's account may be restricted.

### Article 17: Expiration and Forfeiture of Creator Contribution
1. If a Member voluntarily terminates their account or if the account is deleted due to a violation of these Terms, all Creator Contribution held shall be forfeited immediately and shall not be restored.
2. If the Company suspends the Service including Creator Contribution for business reasons, it shall provide at least **30 days** advance notice. Creator Contribution may be forfeited in accordance with the announced policy.

---

### 第7章 青少年保護およびセンシティブコンテンツ運用ポリシー

#### 第18条 (センシティブコンテンツの管理と青少年保護)
1. **センシティブコンテンツの定義:** 「センシティブコンテンツ」とは、合法的な範囲内において、成人向けの表現、暴力性、社会的な議論の要素を含む、年齢制限を要するコンテンツを意味します。ただし、児童ポルノ、児童の性的搾取物、違法な撮影物など、法令に違反する違法コンテンツは絶対に含まれず、本サービス内での作成および流通は厳重に禁止されます。

2. **年齢確認および認証:** センシティブコンテンツの年齢制限枠（19歳以上）にアクセスしたり、「セーフティフィルター」の設定を変更しようとする会員は、必ず実名に基づく本人認証機能（モバイル認証など）を通じて成人であることを証明しなければなりません。未成年アカウントからのアクセスはシステムにより根本的に遮断されます。また、他人の名義の盗用や認証の偽造が発覚した場合は、アカウントが直ちに永久停止されます。当社は、関連法令に従い、年齢認証情報およびアクセスログを最低6ヶ月間保存します。

3. **フィルター設定の変更と利用者の責任:** 成人認証を完了した利用者は、本人の明示的な同意と自発的な意思に基づき、アクセス制限を緩和するための「セーフティフィルター」設定を変更することができます。この機能は、遮断ポリシーを単に違法に迂回するものではなく、自律的な評価システムにおける選択的な権限でのみ運用されます。利用者はフィルターの設定をいつでも元に戻すことができます。ただし、虚偽の情報による登録（VPNの不正利用など）、またはセンシティブコンテンツを故意に外部へ流出、再配布、クロールなどにより拡散させた場合、それに伴う一切の法的責任は利用者本人が負うものとします。

4. **プラットフォームの管理義務と技術的措置:** 当社は単なる免責を主張せず、違法コンテンツの流通を防止するため、以下の積極的な措置を講じます：
   - **AIレベルでの事前/事後分類フィルター:** 違法コンテンツ（児童搾取物やディープフェイク等）の作成を根本から遮断する自動キーワード・文脈検閲システムを導入。
   - **報告受付と即時対応措置:** 監視体制およびユーザーの報告受付時に、問題のあるコンテンツをただちに非公開（ブラインド処理）および削除。
   - **法的措置と協力義務:** フィルターの強制的なバイパス（「ジェイルブレイク」プロンプトの入力等）を試みたユーザーに対しては、スリーストライク制度によりアカウントおよびIPを永久追放します。また、政府機関等からの適法な情報開示要求に対し、関連ログおよび提出可能なデータを提供する法的義務を果たします。

---

### Chapter 8: Disclaimers and Other Matters

#### Article 19 (Disclaimer of Liability)
1. The Company does not guarantee the accuracy or truthfulness of AI-generated responses. Members are advised to verify the appropriateness of such content using their own judgment before relying on it.
2. The Company shall not be liable for service interruptions caused by third-party providers (e.g., Google Gemini, Oracle) or by Force Majeure events beyond the Company's control.

#### Article 20 (Dispute Resolution and Customer Support)
1. Members may contact the Company regarding any issues related to the use of the Service at support@personaxi.com.
2. The Company shall review any disputes or complaints and communicate the result within **5–10 business days** of receipt.
3. If a dispute related to payment remains unresolved through the above process, the Member may escalate the matter to the relevant consumer dispute resolution authority.

#### Article 21 (Governing Law and Jurisdiction)
These Terms shall be governed by and construed in accordance with the laws of the **Republic of Korea**. Any disputes arising from the use of the Service shall be resolved in the court with jurisdiction over the location of the Company's principal place of business.

---

**Company:** PersonaXI  
**Address:** 충청남도 천안시 서북구 번영로 306-15, 104-101, Republic of Korea  
**Customer Support:** support@personaxi.com

**Effective Date:** February 3, 2026
`;export{e as default};
