import{w as s}from"./e6l8DgL1.js";const{subscribe:t,set:e,update:o}=s(!1),r={subscribe:t,hide:()=>e(!0),show:()=>e(!1)};export{r as h};
