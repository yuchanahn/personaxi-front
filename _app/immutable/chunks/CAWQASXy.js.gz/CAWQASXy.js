import{K as n,a4 as d}from"./BUDlkbfV.js";function s(t,a,i){var e=n(t,a);e&&e.set&&(t[a]=i,d(()=>{t[a]=null}))}export{s as b};
