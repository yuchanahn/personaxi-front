import{h as l,a as n}from"./BUDlkbfV.js";function o(r,f,e,a,s){l&&n();var t=f.$$slots?.[e],i=!1;t===!0&&(t=f[e==="default"?"children":e],i=!0),t===void 0||t(r,i?()=>a:a)}export{o as s};
