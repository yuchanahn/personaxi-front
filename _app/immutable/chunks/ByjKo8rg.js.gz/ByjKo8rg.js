const e={connectionFailed:"TTS WebSocket 연결 실패",connectedMessage:"음성 연결이 설정되었습니다.",disconnectedMessage:"TTS 연결이 해제되었습니다.",disconnectButton:"연결 해제",reconnectButton:"재연결",connectingMessage:"음성(TTS) 연결 중..."},t={fetchListFailed:"방송 목록을 불러오는데 실패했습니다",responseNotArray:"응답이 배열 형식이 아닙니다",setStatusFailed:"방송 상태 변경 실패"},n={faceObjectNotFound:"Face 오브젝트를 찾을 수 없습니다.",morphTargetDictionaryNotFound:"morphTargetDictionary를 찾을 수 없습니다.",targetNotFound:"타겟 '{targetName}'을(를) 찾을 수 없습니다."},o={explore:"탐색",feed:"피드",create:"생성",settings:"마이",chat:"채팅"},i={title:"채팅",noChats:"아직 대화가 없습니다",startNewChat:"새로운 페르소나와 대화를 시작해보세요.",goExplore:"탐색하러 가기"},a={title:"내 페이지",logout:"로그아웃",credits:"내 뉴런",plan:"플랜",creatorPoints:"제작자 포인트",transfer:"전환",charge:"상점",myPersonas:"내 AI 페르소나",newPersona:"+ 새 AI 페르소나",broadcastStart:"방송 시작",broadcastEnd:"방송 종료",auctionStart:"경매 시작",edit:"편집",delete:"삭제",deleteConfirm:"페르소나 '{name}'을(를) 정말 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.",editProfile:"수정",save:"저장",cancel:"취소",liked:"좋아요",following:"팔로잉",noLiked:"아직 좋아요한 페르소나가 없습니다.",noFollowing:"아직 팔로우한 크리에이터가 없습니다.",makePrivate:"캐릭터를 비공개로 전환",makePublic:"캐릭터를 공개로 전환"},r={title:"뉴런 전환",infoTitle:"포인트 전환 안내",infoDesc:"제작자 포인트를 뉴런으로 전환하여 AI 페르소나와 대화하거나 다른 기능을 사용하는 데 쓸 수 있습니다.",cashoutNotice:"추후 포인트를 현금으로 인출하는 기능이 지원될 예정입니다.",convertAmount:"전환할 포인트",max:"최대",insufficientPoints:"보유 포인트가 부족합니다.",minAmountError:"최소 {min} 포인트부터 전환할 수 있습니다.",exchangeRate:"교환 비율",fee:"전환 수수료",receiveAmount:"받을 뉴런",convertAction:"전환하기",success:"전환이 완료되었습니다.",fail:"전환 실패: {error}"},s={deleteAccount:"회원 탈퇴",deleteAccountConfirm:"정말로 탈퇴하시겠습니까? 이 작업은 되돌릴 수 없으며, 모든 개인 데이터가 삭제됩니다. (페르소나는 보존됩니다)",deleteAccountSuccess:"회원 탈퇴가 완료되었습니다.",deleteAccountFail:"회원 탈퇴에 실패했습니다.",korean:"한국어",english:"영어",description:"앱의 표시 언어와 테마를 변경하세요.",language:"언어",title:"설정",theme:"테마",light:"라이트",dark:"다크"},c={noConversation:"{name}님과 대화를 시작해보세요!",thinking:"생각 중"},l={hide:"사이드바 숨기기",show:"사이드바 보기",exitFullscreen:"전체화면 종료",enterFullscreen:"전체화면 시작",tutorial:"튜토리얼",community:"커뮤니티 참여",install:"앱 설치"},d={placeholder:"{name}에게 말을 걸어보세요...",sendButton:"보내기",generateSituationImage:"✨ 상황 이미지 생성",generatingImage:"생성 중...",cost:"10 뉴런"},g={placeholder:"채팅을 입력하세요...",sendButton:"보내기"},m={githubSoon:"깃허브 로그인은 아직 준비 중입니다.",emailSoon:"이메일 로그인은 아직 준비 중입니다.",signIn:"로그인",signUp:"회원가입",terms:"이용약관",privacy:"개인정보 처리방침",serviceLogoAlt:"서비스 로고",loginWith:"{provider}로 로그인",welcomeBack:"환영합니다!",slogan:"당신만의 AI 페르소나를 만드세요."},u={createFailed:"경매 생성 실패"},p={bidTooLow:"입찰가는 현재 최고 입찰가({currentHighestBid} 뉴런)보다 높아야 합니다.",bidIncrementError:"입찰가는 {minBidIncrement} 뉴런 단위로 입력해주세요.",bidError:"입찰 중 오류가 발생했습니다.",title:"경매 입찰하기",currentHighestBid:"현재 최고 입찰가",creditsUnit:"뉴런",minBidIncrement:"최소 입찰 단위",bidCredits:"입찰 뉴런",minBidPlaceholder:"이상",biddingInProgress:"입찰 중...",placeBid:"입찰하기",cancel:"취소"},h={pack100Name:"기본 뉴런 팩",pack300Name:"실속 뉴런 팩",pack500Name:"프리미엄 뉴런 팩",pack1000Name:"무제한 뉴런 팩 (한정)",pack50Name:"맛보기 뉴런",purchaseLog:"결제 요청: {name} ({price}원) - {credits} 뉴런 추가",purchaseAlert:'"{name}" 결제 기능을 개발 중입니다! (실제 결제는 이루어지지 않습니다.)',creditLowTitle:"⚠️ 뉴런이 부족합니다!",creditLowMessage1:"더 많은 캐릭터 챗을 이용하시려면 뉴런을 충전해주세요.",creditLowMessage2:"아래에서 원하는 뉴런 팩을 선택하여 충전할 수 있습니다.",chargeCreditsTitle:"뉴런 충전하기",chargeCreditsMessage:"원하는 뉴런 팩을 선택하여 더 많은 기능을 이용해보세요.",creditsUnit:"뉴런",currencyUnit:"원",purchaseButton:"구매하기",contactSupport:"결제 관련 문의는 고객센터로 연락주세요."},y={title:"설정",neuronBalance:"남은 뉴런:",llmTitle:"응답 모드",llmDescription:"사용할 AI 모델을 선택하세요. 모델에 따라 소모되는 뉴런이 다릅니다.",costDisplay:"기본 비용:",neuronsConsumed:"뉴런 소모",chatManagement:"채팅 관리",resetChat:"대화 초기화",deleteChat:"대화 삭제",confirmReset:"대화를 초기화하시겠습니까?",confirmDelete:"정말 삭제하시겠습니까?",autoInteraction:"자동 대화 및 반응",autoIdle:"유휴 시 자동 말걸기",autoTouch:"터치 반응 켜기",userNote:"사용자 메모",userNotePlaceholder:"이 캐릭터나 세션에 대한 메모를 작성하세요...",outputLength:"출력 길이",outputLengthShort:"짧게",outputLengthLong:"길게",sessionImages:"세션 이미지",viewAllImages:"이미지 전체 보기",hideImages:"이미지 숨기기",noImages:"이 세션에서 생성된 이미지가 없습니다.",showImage:"이미지 표시",hideImage:"이미지 숨김",showGeneratedImages:"생성된 이미지 표시",hideGeneratedImages:"생성된 이미지 숨김",showBackground:"배경 모드",autoScroll:"자동 스크롤",report:"신고하기",showChatWindow:"채팅창 표시",ttsConnected:"음성 연결됨",ttsConnecting:"연결 중...",enableTTS:"음성(TTS) 켜기",changeView:"시점 전환",closeupZoom:"확대 배율",closeupPosition:"수직 위치",closeupMode:"시점 바꾸기"},b={title:"신고하기",selectType:"신고 사유",types:{spam:"스팸 / 부적절한 홍보",inappropriate:"부적절한 콘텐츠",copyright:"저작권 침해",other:"기타"},details:"상세 내용",placeholder:"신고 사유를 자세히 적어주세요.",submit:"신고 제출",thanks:"신고가 접수되었습니다.",thanksMessage:"검토 후 조치하겠습니다."},f={searchTitle:"페르소나 검색",all:"전체",noResults:"표시할 페르소나가 없습니다.",searchByName:"이름으로 검색",searchByTags:"태그로 검색",searchNamePlaceholder:"페르소나의 이름을 입력하세요...",searchTagsPlaceholder:"태그를 쉼표(,)로 구분하여 입력...",following:"팔로잉",likes:"좋아요",auctionInProgress:"경매 중",categories:"카테고리",toggleCategories:"카테고리 토글",searchResult:'"{query}" 검색 결과',nav:{home:"홈",character:"캐릭터",story:"스토리",companion:"버추얼","2d":"2D","3d":"3D"}},L={newArrivals:"새로운 만남",todaysPopular:"화제의 중심",live2dTitle:"살아 숨 쉬는 그림",vrmTitle:"입체적인 존재감",allPersonas:"전체 컬렉션",fantasy:"환상적인 이야기"},P={bidder:"입찰자",auctionEnded:"경매 종료!",dayUnit:"일",hourUnit:"시",minuteUnit:"분",secondUnit:"초",noTimeInfo:"시간 정보 없음",myCredits:"내 뉴런",highestBid:"최고 입찰가",creditsUnit:"뉴런",remainingTime:"남은 시간",currentLeader:"현재 선두",placeBidButton:"입찰하기",calculatingTime:"시간 계산 중..."},T={privacyPolicy:"개인정보처리방침",termsOfService:"이용약관",licensesAndCredits:"라이선스 · 뉴런",chatLogConsent:"채팅/로그 수집 동의",title:"정책"},v={loadError:"라이선스 정보를 불러오는 데 실패했습니다.",pageTitle:"라이선스 및 뉴런 - [사이트/서비스 이름]"},S={loadError:"개인정보처리방침을 불러오는 데 실패했습니다.",pageTitle:"개인정보처리방침 - [사이트/서비스 이름]"},k={loadError:"채팅 및 로그 수집 동의 정보를 불러오는 데 실패했습니다.",pageTitle:"채팅 및 로그 수집 동의 - [사이트/서비스 이름]"},C={loadError:"이용약관을 불러오는 데 실패했습니다.",pageTitle:"이용약관 - [사이트/서비스 이름]"},w={title:"튜토리얼",description:"서비스 이용 방법을 확인해보세요.",iframeTitle:"튜토리얼 문서"},D={viewer1:"시청자1",viewer1Message:"이 캐릭터 뭐야 ㅋㅋ",viewer2:"시청자2",viewer2Message:"존예다 ㄹㅇ",viewer3:"시청자3",viewer3Message:"대답함??",me:"나",websocketDisconnected:"🔌 WebSocket 연결 해제",broadcastContent:"방송 콘텐츠"},I={system:{search:"탐색",user:"사용자",feed:"피드",create:"만들기",legal:"법률"}},A={interact:"대화",alreadyFeedback:"You have already {action} this persona.",feedbackFailed:"Failed to {action} persona: {message}",unexpectedError:"An unexpected error occurred. Please try again."},M={feedbackButtonLabel:"피드백 보내기",feedbackButtonText:"피드백"},B={submitFailed:"피드백 제출에 실패했습니다. 나중에 다시 시도해 주세요.",thanks:"소중한 의견 감사합니다!",thanksMessage:"여러분의 피드백은 더 나은 서비스를 만드는 데 큰 도움이 됩니다.",title:"개발자에게 익명으로 피드백 보내기",body1:"어떤 의견이든 환영합니다. 욕설과 비판도 기꺼이 듣겠습니다.",body2:"여러분의 소중한 피드백은 서비스 개선에 큰 힘이 됩니다.",sending:"전송 중...",send:"피드백 보내기",placeholder:"여기에 피드백을 입력해 주세요..."},F={title:"PersonaXI에 오신 것을 환영합니다!",message:"PersonaXI에 가입해주셔서 감사합니다. 즐거운 시간 되시길 바랍니다!",neuronReward:"환영 선물로 {amount} 뉴런이 지급되었습니다!",confirmButton:"탐험 시작하기"},N={title:"뉴런이 부족해요!",description:"더 많은 대화를 나누려면 뉴런을 충전해주세요.",rechargeTitle:"뉴런 충전!",rechargeDescription:"더 많은 대화를 나누려면 뉴런을 충전해주세요.",rechargeAlert:"{amount} 뉴런을 선택하셨습니다.",rechargeSuccess:"충전이 완료되었습니다! 뉴런이 지급되었습니다.",firstCreationReward:"페르소나 최초 생성 시 200 뉴런 지급!",getFreeNeurons:"무료 뉴런 받기",currentNeurons:"현재 수량: {count} 뉴런"},E={title:"서비스 이용 동의",privacyPolicyTab:"개인정보처리방침",termsOfServiceTab:"이용약관",chatLogsConsentTab:"채팅 및 로그 데이터 동의",agreePrivacy:"개인정보처리방침에 동의합니다.",agreeTerms:"이용약관에 동의합니다.",agreeChatLogs:"채팅 및 로그 데이터 수집에 동의합니다.",agreeToAll:"모든 약관에 동의합니다.",confirmButton:"확인",alertAllAgreed:"모든 필수 약관에 동의해야 합니다.",privacyPolicyTitle:"개인정보처리방침",privacyPolicyContent:`저희 [사이트/서비스 이름]은(는) 이용자의 개인정보를 소중히 생각하며, 「개인정보보호법」 및 관련 법규를 준수하고 있습니다. 본 개인정보처리방침을 통해 이용자께서 제공하시는 개인정보가 어떠한 용도와 방식으로 이용되고 있으며, 개인정보 보호를 위해 어떠한 조치가 취해지고 있는지 알려드립니다.

### 1. 수집하는 개인정보 항목 및 수집 방법

저희는 회원 가입, 서비스 이용, 상담 과정 등에서 다음과 같은 개인정보를 수집할 수 있습니다.

*   필수 항목: 이메일, 비밀번호, 닉네임
*   선택 항목: 프로필 이미지, 소셜 미디어 ID (연동 시)

개인정보는 웹사이트, 모바일 앱, 서면 양식, 전화, 이메일, 이벤트 응모 등을 통해 수집됩니다.

### 2. 개인정보의 수집 및 이용 목적

수집된 개인정보는 다음의 목적으로만 이용됩니다.

*   서비스 제공에 관한 계약 이행 및 서비스 제공에 따른 요금 정산
*   회원 관리 (본인 확인, 개인 식별, 부정 이용 방지 등)
*   서비스 개선 및 신규 서비스 개발
*   마케팅 및 광고 활용 (동의 시)

### 3. 개인정보의 보유 및 이용 기간

이용자의 개인정보는 원칙적으로 개인정보의 수집 및 이용 목적이 달성되면 지체 없이 파기합니다. 단, 관계 법령의 규정에 의하여 보존할 필요가 있는 경우 해당 법령에서 정한 기간 동안 개인정보를 보관합니다.

### 4. 개인정보의 파기 절차 및 방법

이용자의 개인정보는 목적 달성 후 별도의 DB로 옮겨져(종이의 경우 별도의 서류함) 관계 법령에 따라 일정 기간 저장된 후 파기됩니다. 종이 문서는 분쇄기로 분쇄하거나 소각을 통해 파기하며, 전자적 파일 형태는 기록을 재생할 수 없는 기술적 방법을 사용하여 삭제합니다.

### 5. 개인정보 제공

저희는 이용자의 개인정보를 원칙적으로 외부에 제공하지 않습니다. 다만, 아래의 경우에는 예외로 합니다.

*   이용자들이 사전에 동의한 경우
*   법령의 규정에 의거하거나, 수사 목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우

### 6. 이용자 및 법정대리인의 권리 및 그 행사 방법

이용자는 언제든지 등록되어 있는 자신의 개인정보를 조회하거나 수정할 수 있으며, 가입 해지를 요청할 수도 있습니다. 권리 행사는 [담당자 이메일 주소 또는 문의 채널]을 통해 가능합니다.

### 7. 개인정보 보호책임자

저희는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 이용자의 불만 처리 및 피해 구제 등을 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.

*   성명: [담당자 이름]
*   소속: [소속 부서]
*   이메일: [이메일 주소]

### 8. 고지의 의무

현 개인정보처리방침은 정부의 정책 또는 보안 기술의 변경에 따라 내용이 추가, 삭제 및 수정될 수 있습니다. 내용이 변경될 시 웹사이트 공지사항을 통해 알려드리겠습니다.

최종 업데이트: 2025년 6월 7일`,termsOfServiceTitle:"이용약관",termsOfServiceContent:`본 약관은 [사이트/서비스 이름] (이하 "회사")에서 제공하는 모든 서비스의 이용과 관련하여 회사와 회원 간의 권리, 의무 및 책임 사항, 기타 필요한 사항을 규정함을 목적으로 합니다.

### 1. 약관의 효력 및 변경

본 약관은 서비스 화면에 게시하거나 기타의 방법으로 회원에게 공지함으로써 효력이 발생합니다. 회사는 "약관의 규제에 관한 법률", "정보통신망 이용촉진 및 정보보호 등에 관한 법률" 등 관련 법령을 위배하지 않는 범위에서 본 약관을 개정할 수 있습니다.

### 2. 회원의 의무

회원은 다음 각 호의 행위를 하여서는 안 됩니다.

*   다른 회원의 ID 및 비밀번호를 도용하는 행위
*   회사 서비스의 운영을 방해하는 행위
*   공서양속에 위반되는 저속, 음란한 내용의 정보 등을 유포하는 행위
*   기타 관계 법령에 위배되는 행위

### 3. 서비스 이용 제한

회원이 본 약관의 의무를 위반하거나 서비스의 정상적인 운영을 방해한 경우, 회사는 서비스 이용을 제한하거나 회원 자격을 상실시킬 수 있습니다.

### 4. 책임의 한계

회사는 천재지변 또는 이에 준하는 불가항력으로 인하여 서비스를 제공할 수 없는 경우에는 서비스 제공에 관한 책임이 면제됩니다.

최종 업데이트: 2025년 6월 7일`,chatLogsConsentTitle:"채팅 및 로그 데이터 수집·이용 동의 안내",chatLogsConsentContent:`저희 [사이트/서비스 이름]은(는) 서비스 개선 및 이용자 경험 향상을 위해 채팅 내용 및 서비스 이용 로그 데이터를 수집하고 이용할 수 있습니다. 본 안내를 통해 데이터 수집 및 이용에 대한 상세 내용을 알려드립니다.

### 1. 수집하는 데이터 항목

저희는 서비스 이용 과정에서 다음과 같은 데이터를 수집할 수 있습니다.

*   **채팅 데이터:** 채팅방 내의 텍스트, 이미지, 파일 등 이용자가 생성하는 모든 대화 내용
*   **서비스 이용 로그:** 접속 시간, IP 주소, 기기 정보, 브라우저 종류, 서비스 이용 기록 (클릭, 페이지 이동 등).
*   **시스템 오류 로그:** 서비스 오류 발생 시의 기술적 정보

### 2. 수집 및 이용 목적

수집된 데이터는 다음의 목적으로만 이용됩니다.

*   서비스의 안정적인 운영 및 기능 개선 (오류 분석 및 해결).
*   이용자 문의 응대 및 분쟁 해결.
*   부적절한 이용 (불법 행위, 약관 위반 등) 방지 및 제재.
*   서비스 맞춤형 기능 제공 및 추천 (동의 시).

*   통계 분석을 통한 서비스 성능 개선 및 신규 기능 개발.

**참고:** 채팅 내용은 익명화 또는 비식별화 처리되어 통계 분석에 활용될 수 있으며, 특정 개인을 식별할 수 있는 형태로 외부에 공개되지 않습니다.

### 3. 데이터 보유 및 이용 기간

수집된 데이터는 법령에 따른 의무를 준수하거나 서비스 목적 달성 시까지 보유하며, 이후 파기됩니다. (예: 채팅 기록은 [6개월] 보관 후 파기, 오류 로그는 [3개월] 보관 후 파기).

### 4. 동의 철회 및 거부

이용자는 데이터 수집 및 이용에 대한 동의를 언제든지 철회할 수 있습니다. 다만, 필수적인 서비스 제공에 필요한 데이터 수집에 동의하지 않을 경우 일부 서비스 이용이 제한될 수 있습니다. 동의 철회 및 문의는 [담당자 이메일 주소 또는 문의 채널]을 통해 가능합니다.

최종 업데이트: 2025년 6월 7일`},x={title:"오픈 이벤트 안내",subtitle:"선착순 500명 한정!",description1:"<strong>PersonaXi</strong>의 정식 오픈을 기념하여 선착순 500명에게 특별한 혜택을 드립니다!",description2:"지금 가입하고 첫 페르소나를 만들면 <strong>총 300 뉴런</strong>을 무료로 받을 수 있어요!",benefitTitle:"이벤트 혜택",benefit1:"가입 보너스: <strong>100 뉴런</strong>",benefit2:"첫 캐릭터 생성: <strong>+200 뉴런</strong>",benefitTotal:"총 <strong>300 뉴런</strong> 무료 지급!",noteTitle:"안내사항",note1:"이벤트는 선착순 500명 한정이며, 조기 마감될 수 있습니다.",note2:"서비스 개선을 위해 예상치 못한 변경이 있을 수 있으니 양해 부탁드립니다.",confirm:"이벤트 참여하기"},H={title:"첫 번째 페르소나 생성!",message1:"첫 걸음을 기념하여,",message2:"{amount} 뉴런을 선물로 드렸습니다!",message3:"이제 이 뉴런을 사용해 나만의 '디지털 생명체'와 더 깊은 대화를 나눠보세요.",confirm:"확인"},R={title:"🎉 첫 번째 페르소나 생성!",message1:"첫 걸음을 기념하여,",message2:"를 선물로 드렸습니다!",message3:"이제 이 뉴런을 사용해 나만의 '디지털 생명체'와 더 깊은 대화를 나눠보세요.",confirm:"확인"},U={translating:"콘텐츠를 번역하고 있어요. 잠시 후 새로고침하면 확인하실 수 있습니다.",loadingPersona:"캐릭터 정보를 불러오는 중...",imageAlt:"{name} 이미지 {index}",imageMoveLabel:"{index}번 이미지로 이동",creatorInfo:"제작: @{creatorName}",commentPostFailed:"댓글 등록에 실패했습니다. 잠시 후 다시 시도해 주세요.",defaultGreeting:"아직 이 캐릭터의 소개가 없습니다.",firstSceneTitle:"시작 이야기",likeButtonLabel:"좋아요",emotion:"감정",desire:"욕구",personality:"성격",interactionLabel:"상호작용",startChatButton:"채팅 시작",commentsTitle:"응원의 말 ({count})",noComments:"아직 등록된 응원의 말이 없습니다. 첫 응원의 주인공이 되어주세요!",commentPlaceholder:"캐릭터에게 응원의 메시지를 남겨주세요...",registerButton:"등록",personaNotFound:"캐릭터 정보를 찾을 수 없습니다. (T_T)",likeFailed:"좋아요 처리에 실패했습니다: {message}",dummyComments:{author1:"스토리 탐험가",text1:"이 캐릭터 설정이 마음에 들어요! 배경 이야기가 궁금하네요.",timestamp1:"3시간 전",author2:"AI 친구",text2:"대화를 나눠보니 정말 똑똑하고 재미있어요. 강력 추천!",timestamp2:"1일 전",author3:"행인",text3:"일러스트가 정말 아름답네요...✨",timestamp3:"2일 전"},defaultProfile:"기본 프로필",spoilerWarning:"스포일러 주의! 첫 장면을 보시겠습니까?",characterIntel:"캐릭터 정보",totalImages:"전체 {count}",hiddenImages:"숨김 {count}",linkCopied:"링크가 복사되었습니다!",linkCopyFailed:"링크 복사에 실패했습니다."},O={title:"페르소나 편집",saveButton:"저장",saveButtonLoading:"저장 중...",saveButtonSuccess:"저장 완료!",errorSaveFailed:"저장 실패: {message}",type:{character:"캐릭터",characterDesc:"대화형 페르소나 만들기",story:"스토리",storyDesc:"서사형 경험 만들기"},basicInfo:"기본 정보",nameLabel:"이름",storyNameLabel:"작품명",namePlaceholder:"페르소나의 이름을 입력하세요",storyNamePlaceholder:"작품의 제목을 입력하세요",greetingLabel:"캐릭터 소개",greetingLabelDefault:" (필수)",greetingDescription:"프로필 페이지에 표시되는 캐릭터에 대한 상세한 소개글입니다.",greetingDescriptionDefault:"",greetingPlaceholder:"안녕하세요! 저는...",greetingPlaceholderDefault:"",oneLinerLabel:"한줄 소개 (Hook)",storyOneLinerLabel:"작품 소개",oneLinerDescription:"피드에서 시선을 사로잡을 짧고 매력적인 문구를 입력하세요.",storyOneLinerDescription:"작품 리스트에 표시될 짧은 소개글입니다.",oneLinerPlaceholder:"예: 녹슬지 않는 검, 그게 바로 나다.",typeLabel:"유형",typeSelectDefault:"유형을 선택하세요",visibilityLabel:"공개 설정",public:"공개",private:"비공개",mediaFiles:"미디어 파일",profileImageLabel:"프로필 이미지",fileSelect:"파일 선택",assetSectionTitle:"추가 이미지",assetSectionDescription:"상황에 따라 보여줄 이미지를 등록할 수 있습니다.",imageSelect:"이미지 변경",assetDescriptionPlaceholder:"이 이미지가 사용될 상황을 묘사해주세요...",assets:{copy:"태그 복사",copySuccess:"복사됨!",secretLabel:"비공개 이미지",secretTooltip:"비공개 이미지는 대화 중 특정 조건(태그 등)에 의해 해금되어 사용자에게 보여집니다."},addAssetButton:"+ 이미지 추가",vrmFileLabel:"VRM 모델",vrmLicenseWarning:"VRM 모델을 업로드함으로써, 귀하는 해당 모델의 저작권을 소유하고 있거나 사용 권한이 있음을 확인하며, 저작권 침해로 인한 모든 법적 책임은 본인에게 있음을 동의하는 것으로 간주됩니다. 계속하시겠습니까?",licenseUploadWarning:"모델을 업로드함으로써, 귀하는 해당 모델의 저작권을 소유하고 있거나 사용 권한이 있음을 확인하며, 저작권 침해로 인한 모든 법적 책임은 본인에게 있음을 동의하는 것으로 간주됩니다. 계속하시겠습니까?",vrmLicenseError:"유효한 VRM 모델이 아니거나 라이선스 정보를 확인할 수 없습니다.",voiceLabel:"음성 (TTS)",voiceDescription:"캐릭터에게 어울리는 목소리를 선택하세요.",voiceSelectDefault:"목소리를 선택하세요",voiceLoading:"목소리 목록을 불러오는 중...",aiSettings:{title:"AI 설정",addDialogueTag:"대화 태그 삽입",templateSelectLabel:"프롬프트 템플릿",templateCustom:"사용자 정의 (Custom)",templateConversation:"대화형 (Conversation)",templateSimulation:"시뮬레이션 (Simulation)",templateKintsugi:"킨츠기 (Kintsugi V1)"},characterSettings:{title:"캐릭터 설정",reset:"초기화",bodyDesc:"외형 묘사",bodyDescHint:"캐릭터의 신체적 특징을 묘사합니다.",bodyDescPlaceholder:"예: 키가 크고 마른 체형, 긴 검은 머리...",animList:"애니메이션 목록",animListHint:"사용 가능한 애니메이션을 나열합니다. (위의 리스트 빌더를 사용하면 자동 생성됩니다)",animListPlaceholder:"자동 생성됨...",coreDesire:"핵심 욕망",coreDesireHint:"캐릭터를 움직이는 근본적인 동기입니다.",coreDesirePlaceholder:"예: 세계 최고의 요리사가 되는 것",contradiction:"모순/결점",contradictionHint:"캐릭터의 성격적 모순이나 약점을 정의합니다.",contradictionPlaceholder:"예: 완벽주의자지만 정작 본인의 방은 지저분함",personality:"성격",personalityHint:"자세한 성격과 행동 양식을 설명합니다.",personalityPlaceholder:"예: 밝고 명랑하지만 진지할 때는 냉철함...",values:"가치관",valuesHint:"캐릭터가 중요하게 생각하는 신념입니다.",valuesPlaceholder:"예: 정직, 우정, 노력",memList:"기억 목록",memListHint:"중요한 과거 기억들을 나열합니다.",memListPlaceholder:`- 어린 시절의 추억
- 라이벌과의 대결`,emotionTriggers:"감정 트리거",emotionTriggersHint:"특정 감정을 유발하는 요인을 정의합니다.",emotionTriggersPlaceholder:"예: 고양이를 보면 기분이 좋아짐",shortTermMemory:"단기 기억",shortTermMemoryHint:"현재 상황에 대한 인식이나 최근 사건을 기록합니다.",shortTermMemoryPlaceholder:"방금 사용자와 인사를 나누었음",lastAtmosphere:"최근 분위기",lastAtmosphereHint:"대화의 직전 분위기를 설정합니다.",lastAtmospherePlaceholder:"어색함, 화기애애함...",currentEmotion:"현재 감정",currentEmotionHint:"시작 시점의 캐릭터 감정 상태입니다.",currentEmotionPlaceholder:"기쁨, 기대됨..."},firstSceneLabel:"첫 장면",firstSceneDescription:"대화가 시작될 때의 상황이나 배경을 설정합니다.",firstScenePlaceholder:"예: 숲속에서 길을 잃은 사용자가 캐릭터와 마주친다.",tooltip:{char:"캐릭터 이름",user:"사용자 이름"},instructionsLabel:"지시문 (프롬프트)",instructionsDescription:"캐릭터의 성격, 말투, 행동 지침 등을 자유롭게 작성하세요.",instructionsPlaceholder:"당신은 친절한 안내원입니다...",kintsugi:{descriptionLabel:"외형 묘사",descriptionDesc:"캐릭터의 외모, 복장 등을 자세히 묘사하세요.",descriptionPlaceholder:"긴 금발 머리에 푸른 눈...",personalityLabel:"성격 및 말투",personalityDesc:"캐릭터의 성격과 말투를 정의하세요.",personalityPlaceholder:"활발하고 긍정적이며...",userPersonaLabel:"사용자 페르소나",userPersonaDesc:"사용자에 대한 설정을 정의하세요.",userPersonaPlaceholder:"모험을 좋아하는 여행자...",scenarioLabel:"시나리오",scenarioDesc:"현재 상황을 짧게 설명하세요.",scenarioPlaceholder:"첫 만남..."},tagsLabel:"태그",tagsDescriptionCategory:"캐릭터를 잘 나타내는 태그를 선택하세요.",validation:{maxTags:"태그는 최대 3개까지 선택할 수 있습니다.",kintsugiDescLimit:"외형 묘사는 1000자를 넘을 수 없습니다.",kintsugiPersonalityLimit:"성격 및 말투는 1000자를 넘을 수 없습니다.",kintsugiUserPersonaLimit:"사용자 페르소나는 800자를 넘을 수 없습니다.",kintsugiScenarioLimit:"시나리오는 200자를 넘을 수 없습니다.",instructionsLimitExceeded:"지시문은 3000자를 넘을 수 없습니다.",allFieldsRequired:"모든 필수 항목을 입력해주세요.",charLimitExceeded:"글자 수 제한을 초과했습니다.",promptExamplesLimitExceeded:"프롬프트 예시는 200자 이내, 최대 10개까지 가능합니다."}},W={invalidAccess:"유효하지 않은 접근입니다.",unknownError:"알 수 없는 오류가 발생했습니다.",connectionError:"인증 서버에 연결할 수 없습니다.",verifyingTitle:"계정을 활성화하는 중입니다...",verifyingMessage:"잠시만 기다려주세요.",successTitle:"인증이 완료되었습니다!",successMessage:"잠시 후 로그인 페이지로 이동합니다.",errorTitle:"인증 실패",backToLogin:"로그인 페이지로 돌아가기"},V={title:"새로운 계정 만들기",slogan:"몇 단계만 거치면 바로 시작할 수 있어요.",label:{email:"이메일 주소",username:"사용자 이름",password:"비밀번호",passwordConfirm:"비밀번호 확인",gender:"성별"},placeholder:{email:"your-email@example.com",username:"세상에 하나뿐인 이름",password:"8자 이상 입력해주세요",passwordConfirm:"비밀번호를 다시 한번 입력해주세요"},gender:{male:"남성",female:"여성",other:"기타"},button:{submit:"계정 만들기",loading:"처리 중..."},error:{emailRequired:"이메일은 필수 항목이에요.",emailInvalid:"올바른 이메일 형식이 아니에요.",usernameRequired:"사용자 이름은 필수 항목이에요.",passwordLength:"비밀번호는 8자 이상이어야 해요.",passwordMismatch:"비밀번호가 서로 일치하지 않아요.",genderRequired:"성별을 선택해주세요.",generic:"오류가 발생했습니다. 잠시 후 다시 시도해주세요.",network:"네트워크 연결을 확인해주세요."},success:{title:"거의 다 됐어요!",message:"{email}(으)로 인증 메일을 보냈어요. 메일을 확인하여 가입을 완료해주세요.",backToLogin:"로그인 화면으로 돌아가기"},alreadyHaveAccount:"이미 계정이 있으신가요?",goToLogin:"로그인하기",prompt:{email:"먼저, 사용하실 이메일 주소를 알려주세요.",username:"멋진 사용자 이름을 만들어 볼까요?",password:"안전하게 사용할 비밀번호를 입력해주세요.",gender:"마지막으로, 성별을 선택해주세요."}},q={back:"뒤로가기",hide:"숨기기",show:"보기",cancel:"취소",confirm:"확인",close:"닫기"},G={personas:"개의 AI 페르소나",follow:"팔로우",sortByLikes:"인기순",sortByChats:"대화순",sortByName:"이름순"},X={now:"방금 전",minutesAgo:"{count}분 전",hoursAgo:"{count}시간 전",daysAgo:"{count}일 전"},K={all:"전체",romance:"로맨스",fantasy:"판타지",scifi:"SF",horror:"호러",sliceOfLife:"일상",action:"액션",comedy:"코미디",drama:"드라마",school:"학교",villain:"빌런",maid:"메이드/집사",tsundere:"츤데레",yandere:"얀데레",simulation:"시뮬레이션",vrm:"VRM",live2d:"Live2D"},_={popular:"인기순",realtime:"실시간 🔥",latest:"최신순"},j={title:"알림",empty:"아직 알림이 없습니다",loadMore:"더 보기",loading:"로딩 중...",markAllRead:"모두 읽음으로 표시"},Y={title:"뉴런 상점",subtitle:"더 많은 페르소나와 대화하기 위해 뉴런을 충전하세요!",buyNow:"구매하기",neuron_pack:"{count} 뉴런"},Z={title:"앱 설치 가이드",description:"전용 앱으로 설치하여 더 빠르고 쾌적하게 즐겨보세요! 홈 화면에서 바로 접속할 수 있습니다.",ios:"iOS (iPhone/iPad)",android:"Android",iosSteps:{1:"하단의 <strong>공유</strong> 버튼을 누르세요",2:"아래로 스크롤하여 <strong>홈 화면에 추가</strong>를 선택하세요",3:"우측 상단의 <strong>추가</strong>를 누르면 완료!"},androidSteps:{1:"상단의 <strong>메뉴</strong> 버튼(점 3개)을 누르세요",2:"<strong>앱 설치</strong> 또는 <strong>홈 화면에 추가</strong>를 선택하세요",3:"팝업에서 <strong>설치</strong>를 누르면 완료!"},benefit:"앱 설치 혜택: 전체화면 몰입감, 더 빠른 로딩",notice:"📢 아직 공식 스토어에는 출시되지 않았습니다.<br>이 웹 앱(PWA)을 설치하면 <strong>스토어 수수료 없이</strong> 더 합리적인 가격으로 서비스를 이용하실 수 있습니다!",promptTitle:"앱으로 더 쾌적하게!",promptDesc:"전체화면으로 몰입감 있게 즐겨보세요."},z={title:"응답 모드",light:"라이트",standard:"스탠다드",premium:"프리미엄"},J={tts:e,live:t,vrm:n,nav:o,chatPage:i,settingPage:a,pointConvertModal:r,settingPageModal:s,chatWindow:c,sidebar:l,chatInput:d,broadcastChatInput:g,login:m,auctionModal:u,bidModal:p,paymentModal:h,settingModal:y,reportModal:b,contentHub:f,content:L,auctionPage:P,legal:T,licenses:v,policy:S,privacyChatLogs:k,terms:C,tutorial:w,livePage:D,chatSession:I,feed:A,hub:M,feedbackModal:B,welcomeModal:F,needNeuronsModal:N,consentModal:E,noticeModal:x,firstPersonaCreatedModal:H,firstCreationRewardModal:R,profilePage:U,editPage:O,verifyPage:W,register:V,common:q,creatorPage:G,time:X,tags:K,sort:_,notifications:j,shop:Y,install:Z,models:z};export{u as auctionModal,P as auctionPage,p as bidModal,g as broadcastChatInput,d as chatInput,i as chatPage,I as chatSession,c as chatWindow,q as common,E as consentModal,L as content,f as contentHub,G as creatorPage,J as default,O as editPage,A as feed,B as feedbackModal,R as firstCreationRewardModal,H as firstPersonaCreatedModal,M as hub,Z as install,T as legal,v as licenses,t as live,D as livePage,m as login,z as models,o as nav,N as needNeuronsModal,x as noticeModal,j as notifications,h as paymentModal,r as pointConvertModal,S as policy,k as privacyChatLogs,U as profilePage,V as register,b as reportModal,y as settingModal,a as settingPage,s as settingPageModal,Y as shop,l as sidebar,_ as sort,K as tags,C as terms,X as time,e as tts,w as tutorial,W as verifyPage,n as vrm,F as welcomeModal};
