import{ac as t}from"./BUDlkbfV.js";function o(e,r){var a=e.$$events?.[r.type],l=t(a)?a.slice():a==null?[]:[a];for(var s of l)s.call(this,r)}export{o as b};
