import{l as o,a as r}from"../chunks/BzpRVRgL.js";export{o as load_css,r as start};
