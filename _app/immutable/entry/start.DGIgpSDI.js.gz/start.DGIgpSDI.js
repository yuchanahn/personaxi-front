import{l as o,c as r}from"../chunks/CwWK4Zkf.js";export{o as load_css,r as start};
